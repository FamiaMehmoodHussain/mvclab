/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
public class Model {
    private String data;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}

class View {
    public void printData(String data) {
        System.out.println("Data: " + data);
    }
}

class Controller {
    private Model model;
    private View view;

    public Controller(Model model, View view) {
        this.model = model;
        this.view = view;
    }

    public String getData() {
        return model.getData();
    }

    public void setData(String data) {
        model.setData(data);
    }

    public void update() {
        view.printData(model.getData());
    }
}

 class Main {
    public static void main(String[] args) {
        Model model = new Model();
        View view = new View();
        Controller controller = new Controller(model, view);

        controller.setData("hello mvc");
        controller.update();
    }
}


