/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample.Model;

public class LaptopModel {
    private String model;
    private String specifications;

    public LaptopModel(String model, String specifications) {
        this.model = model;
        this.specifications = specifications;
    }

    public String getModel() {
        return model;
    }

    public String getSpecifications() {
        return specifications;
    }
}
 class Brand {
    private String name;

    public Brand(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
