/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample;


public class Modifiedmvcexample {   // Model class
    static class Laptop {
        private String model;
        private String specifications;

        public Laptop(String model, String specifications) {
            this.model = model;
            this.specifications = specifications;
        }

        public String getModel() {
            return model;
        }

        public String getSpecifications() {
            return specifications;
        }

        public void setModel(String model) {
            this.model = model;
        }

        public void setSpecifications(String specifications) {
            this.specifications = specifications;
        }
    }

    // View class
    static class LaptopView {
        public void printLaptopDetails(Laptop laptop) {
            System.out.println("Laptop Model: " + laptop.getModel());
            System.out.println("Specifications: " + laptop.getSpecifications());
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        // Create a laptop object
        Laptop laptop = new Laptop("XPS 13", "Intel i7, 16GB RAM, 512GB SSD");
        
        // Create a view object
        LaptopView view = new LaptopView();
        
        // Display initial laptop details
        view.printLaptopDetails(laptop);
        
        // Update laptop details
        laptop.setModel("XPS 15");
        laptop.setSpecifications("Intel i9, 32GB RAM, 1TB SSD");
        
        // Display updated laptop details
        view.printLaptopDetails(laptop);
    }
}