/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample.View;


import modifiedmvcexample.Model.LaptopModel;

public class LaptopView {
    public void printLaptopDetails(Laptop laptop) {
        System.out.println("Laptop Model: " + laptop.getModel());
        System.out.println("Specifications: " + laptop.getSpecifications());
    }

    public void printLaptopDetails(LaptopModel laptop) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
 class BrandView {
    public void printBrandDetails(Brand brand) {
        System.out.println("Brand Name: " + brand.getName());
    }
}