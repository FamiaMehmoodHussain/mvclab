/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample.Controller.main;

import modifiedmvcexample.Controller.LaptopController;
import modifiedmvcexample.Model.LaptopModel;
import modifiedmvcexample.View.LaptopView;


public class LaptopManagementSystem {
    public static void main(String[] args) {
        // Create model objects
        LaptopModel laptop = new LaptopModel("XPS 13", "Intel i7, 16GB RAM, 512GB SSD");
        BrandModel brand = new BrandModel("Dell");

        // Create view objects
        LaptopView laptopView = new LaptopView();
        BrandView brandView = new BrandView();

        // Create controllers
        LaptopController laptopController = new LaptopController(laptop, laptopView);
        BrandController brandController = new BrandController(brand, brandView);

        // Update views
        laptopController.updateView();
        brandController.updateView();

        // Update laptop model and specifications
        laptopController.setLaptopModel("XPS 15");
        laptopController.setLaptopSpecifications("Intel i9, 32GB RAM, 1TB SSD");
        laptopController.updateView();
        
        // Update brand name
        brandController.setBrandName("HP");
        brandController.updateView();
    }
}
