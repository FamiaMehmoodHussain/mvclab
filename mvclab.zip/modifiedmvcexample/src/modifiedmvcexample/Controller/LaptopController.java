/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modifiedmvcexample.Controller;
import modifiedmvcexample.Model.LaptopModel;

import modifiedmvcexample.View.LaptopView;


public class LaptopController {
    private LaptopModel laptop;
    private LaptopView view;

    public LaptopController(LaptopModel laptop, LaptopView view) {
        this.laptop = laptop;
        this.view = view;
    }

    public void setLaptopModel(String model) {
        laptop = new LaptopModel(model, laptop.getSpecifications());
    }

    public void setLaptopSpecifications(String specifications) {
        laptop = new LaptopModel(laptop.getModel(), specifications);
    }

    public void updateView() {
        Laptop laptopView = null;
        view.printLaptopDetails(laptop);
    }
}
